from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='index'),
    path('categories/', views.category_list, name='category_list'),  # Список всех категорий
    path('categories/<int:category_id>/', views.category_detail, name='category_detail'),  # Должно отображать как подкатегории, так и товары в категории
    path('categories/<int:category_id>/subcategories/', views.subcategory_list, name='subcategory_list'),  # Список подкатегорий конкретной категории
    path('subcategories/<int:subcategory_id>/products/', views.product_list, name='product_list'),  # Список продуктов в подкатегории
    path('products/<int:product_id>/', views.product_detail, name='product_detail'),  # Детали конкретного продукта
    path('search/', views.product_search, name='product_search'), # ПОИСКОВАЯ СТРОКА.
    path('about/', views.about_company, name='about_company'),  # About company page
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])


# from django.urls import path

# from . import views
#
# urlpatterns = [
#     path('', views.index, name='index'),
#     path('categories/', views.category_list, name='category_list'),
#     path('categories/<int:category_id>/subcategories/', views.subcategory_list, name='subcategory_list'),
#     path('subcategories/<int:subcategory_id>/products/', views.product_list, name='product_list'),
#     path('products/<int:product_id>/', views.product_detail, name='product_detail'),
# ]
