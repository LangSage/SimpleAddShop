from django.contrib import admin
from django.utils.html import format_html
from .models import Category, SubCategory, Product, ProductImage
from .widgets import CKEditor5Widget
from django import forms
class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1  # Allows adding one more image at a time

class ProductAdminForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = '__all__'
        widgets = {
            'description': CKEditor5Widget(),
        }

class ProductAdmin(admin.ModelAdmin):
    form = ProductAdminForm  # ← Add this line
    list_display = ('name', 'category', 'subcategory', 'image_tag')
    readonly_fields = ('image_tag',)
    search_fields = ('name', 'description')
    filter_horizontal = ('posts',)
    inlines = [ProductImageInline]  # Add ProductImage inline here

    def image_tag(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="50" height="50" />', obj.image.url)
        return 'No Image'
    image_tag.short_description = 'Image'

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'image_tag')
    readonly_fields = ('image_tag',)
    fields = ('name', 'image', 'description')

    def image_tag(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="50" height="50" />', obj.image.url)
        return 'No Image'
    image_tag.short_description = 'Image'

@admin.register(SubCategory)
class SubCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'image_tag')
    readonly_fields = ('image_tag',)

    def image_tag(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="50" height="50" />', obj.image.url)
        return 'No Image'
    image_tag.short_description = 'Image'

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'subcategory', 'image_tag')
    readonly_fields = ('image_tag',)
    inlines = [ProductImageInline]  # Add ProductImage inline here

    def image_tag(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="50" height="50" />', obj.image.url)
        return 'No Image'
    image_tag.short_description = 'Image'
