from django.shortcuts import render, get_object_or_404
from .models import Category, SubCategory, Product
from .forms import ProductSearchForm
from django.db.models import Q
from blog.models import Post  # Assuming the blog app has a Post model

def index(request):
    categories = Category.objects.all()
    posts = Post.objects.all().order_by('-published_at')[:3]  # Latest 3 posts
    return render(request, 'shop/index.html', {'categories': categories, 'posts': posts})

def category_list(request):
    categories = Category.objects.all()
    return render(request, 'shop/category_list.html', {'categories': categories})


def product_search(request):
    form = ProductSearchForm(request.GET)
    query = request.GET.get('query')
    results = []

    if query:
        results = Product.objects.filter(
            Q(name__icontains=query) |
            Q(description__icontains=query)
        )

    # Fetch all categories to display in the sidebar
    categories = Category.objects.all()

    context = {
        'form': form,
        'results': results,
        'query': query,
        'categories': categories,  # Include categories in the context
    }

    return render(request, 'shop/product_search.html', context)



def category_detail(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    subcategories = category.subcategories.all()
    products = Product.objects.filter(
        category=category
    ).exclude(
        subcategory__in=subcategories
    )
    return render(request, 'shop/category_detail.html', {
        'category': category,
        'subcategories': subcategories,
        'products': products,
        'categories': Category.objects.all()
    })

def subcategory_list(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    subcategories = category.subcategories.all()
    products_in_subcategories = Product.objects.filter(subcategory__in=subcategories)
    products = Product.objects.filter(
        category=category
    ).exclude(
        subcategory__in=subcategories
    ) | products_in_subcategories
    return render(request, 'shop/subcategory_list.html', {
        'category': category,
        'subcategories': subcategories,
        'products': products,
        'categories': Category.objects.all()
    })

def product_list(request, subcategory_id):
    subcategory = get_object_or_404(SubCategory, id=subcategory_id)
    products = Product.objects.filter(subcategory=subcategory)
    return render(request, 'shop/product_list.html', {
        'subcategory': subcategory,
        'products': products,
        'categories': Category.objects.all()
    })

def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'shop/product_detail.html', {
        'product': product,
        'categories': Category.objects.all()
    })



def about_company(request):
    # Fetch all categories
    categories = Category.objects.all()
    # Pass categories to the template
    return render(request, 'shop/about_company.html', {'categories': categories})